import React from "react";

const app = () => (
    <header id="ucHeader" role="banner">
        <div>
            {/*<img src="/img/brand/logo_white.svg" alt=""/>*/}
            <p>BTMS application</p>
        </div>
    </header>
);

export default app;