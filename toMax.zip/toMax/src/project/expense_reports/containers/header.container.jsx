import {connect} from "react-redux"
import component from "../components/header.component";

const mapStateToProps = state => {

}

const mapDispatchToProps = state => {

}

export default connect(mapStateToProps, mapDispatchToProps)(component)