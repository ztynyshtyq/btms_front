import * as constants from "./constants";
import * as events from "./events";

//TODO dopisat' modul'nyi framework
const _auth_failed = () => {

}