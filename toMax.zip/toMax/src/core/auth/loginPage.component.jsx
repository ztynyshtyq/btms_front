import React from "react";

const component = () => (
    <div>
        <p>adwdadawdawdaw</p>
    </div>
)

export default component;