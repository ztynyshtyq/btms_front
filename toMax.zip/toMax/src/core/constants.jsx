export const EVENT_REQUEST_INITIATED = "event_request_initiated";
export const EVENT_REQUEST_PROCESSED = "event_request_processed";