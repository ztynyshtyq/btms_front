import reducer from "./auth/reducer";

export {reducer};
